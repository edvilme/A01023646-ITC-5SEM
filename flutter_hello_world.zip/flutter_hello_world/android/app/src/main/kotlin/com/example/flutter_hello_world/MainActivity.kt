package com.example.flutter_hello_world

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
